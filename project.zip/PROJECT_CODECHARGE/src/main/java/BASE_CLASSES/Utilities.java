package BASE_CLASSES;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
	
	protected static WebDriver dr;
	
	public Utilities() {
		this.dr=dr;
	}
	
	
	public static WebDriver launch_browser(String browser, String url)
	{
		
		if(browser.contains("CHROME"))
		{
			System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\Drivers\\chromedriver_v79.exe");
			dr= new ChromeDriver();
		}	
		else if(browser.contains("FIREFOX")) {
			System.setProperty("webdriver.gecko.driver","src\\test\\resources\\Drivers\\geckoDriver.exe");
			dr = new FirefoxDriver();
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		return dr;
	}

}
