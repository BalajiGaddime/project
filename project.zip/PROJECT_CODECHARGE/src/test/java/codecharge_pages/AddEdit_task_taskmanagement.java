package codecharge_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class AddEdit_task_taskmanagement {
	WebDriver dr;
	
	public AddEdit_task_taskmanagement(WebDriver dr)
	{
		System.out.println("in AddEdit_task_taskmanagement");
		this.dr=dr;
	}
	
	By addtask=By.xpath("//a[@href='TaskRecord.php']");
	By task=By.xpath("//form[@name='task']/table[2]/tbody/tr[1]/td/input");
	By descr=By.xpath("//form[@name='task']/table[2]/tbody/tr[2]/td/textarea");
	By proj=By.xpath("//form[@name='task']/table[2]/tbody/tr[3]/td/select");
	By prio=By.xpath("//form[@name='task']/table[2]/tbody/tr[4]/td/select");
	By status=By.xpath("//form[@name='task']/table[2]/tbody/tr[5]/td/select");
	By type=By.xpath("//form[@name='task']/table[2]/tbody/tr[6]/td/select");
	By assign=By.xpath("//form[@name='task']/table[2]/tbody/tr[7]/td/select");
	By sdate=By.xpath("//form[@name='task']/table[2]/tbody/tr[8]/td/input");
	By fdate=By.xpath("//form[@name='task']/table[2]/tbody/tr[9]/td/input");
	By addbtn=By.xpath("//input[@name='Insert']");

	
	public void clk_addtask() {
		System.out.println("in clk_addtask");
		dr.findElement(addtask).click();
	}
	
	public void set_task(String t) {
		System.out.println("in set_task");

		dr.findElement(task).sendKeys(t);
	}
	public void set_descr(String d) {
		System.out.println("in set_descr");

		dr.findElement(descr).sendKeys(d);
	}
	public void set_proj() {
		System.out.println("in set_proj");

		WebElement we_pj=dr.findElement(proj);
		Select sel1=new Select((WebElement) we_pj);
		sel1.selectByVisibleText("CodeCharge");
	}
	public void set_prio() {
		System.out.println("in set_prio");

		WebElement we_prio=dr.findElement(prio);
		Select sel1=new Select((WebElement) we_prio);
		sel1.selectByVisibleText("High");
	}
	public void set_status( ) {
		System.out.println("in set_status");

		WebElement we_status=dr.findElement(status);
		Select sel1=new Select((WebElement) we_status);
		sel1.selectByVisibleText("Closed");
	}
	public void set_type() {
		System.out.println("in set_type");

		WebElement we_type=dr.findElement(type);
		Select sel1=new Select((WebElement) we_type);
		sel1.selectByVisibleText("Bug");
	}
	public void set_assign() {
		WebElement we_assign=dr.findElement(assign);
		Select sel1=new Select((WebElement) we_assign);
		sel1.selectByVisibleText("Alex Knievel");
	}
	public void set_sdate(String sd) {
		dr.findElement(sdate).sendKeys(sd);
	}
	public void set_fdate(String fd) {
		dr.findElement(fdate).sendKeys(fd);
	}
	public void clk_add() {
		dr.findElement(addbtn).click();
	}
	
	
	public void do_addtask(String a, String b, String c, String d) throws InterruptedException {
		System.out.println("in do addtask");
		this.clk_addtask();
		Thread.sleep(3000);

		this.set_task(a);
		this.set_descr(b);
		this.set_proj();
		this.set_prio();
		this.set_status();
		this.set_type();
		this.set_assign();
		this.set_sdate(c); 
		this.set_fdate(d);
		this.clk_add();
		
	}
	

}
