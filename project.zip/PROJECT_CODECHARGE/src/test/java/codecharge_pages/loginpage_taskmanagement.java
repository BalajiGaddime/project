package codecharge_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage_taskmanagement {
	WebDriver dr;
	public loginpage_taskmanagement(WebDriver dr)
	{
		System.out.println("in loginpage_taskmanagement");
		this.dr=dr;
	}
	
	By uname=By.xpath("//table[@class='Record']/tbody/tr[1]/td[2]/input");
	By pwd=By.xpath("//table[@class='Record']/tbody/tr[2]/td[2]/input");
	By login=By.xpath("//table[@class='Record']/tbody/tr[3]/td/input");

	public void set_uname(String n) {
		dr.findElement(uname).sendKeys(n);
	}
	public void set_pwd(String p) {
		dr.findElement(pwd).sendKeys(p);
	}
	public void clk_login() {
		dr.findElement(login).click();
	}
	
	public void do_login(String a, String b) {
		this.set_uname(a);
		this.set_pwd(b);
		this.clk_login();
	}

}
