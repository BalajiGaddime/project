package codecharge_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class search_taskmanagement {
	WebDriver dr;
	
	public search_taskmanagement(WebDriver dr)
	{
		System.out.println("in search_taskmanagement");
		this.dr=dr;
	}
	
	
	By assto= By.xpath("//form[@name='search']/table[2]/tbody/tr[1]/td/select");
	By proj= By.xpath("//form[@name='search']/table[2]/tbody/tr[2]/td/select");
	By prio= By.xpath("//form[@name='search']/table[2]/tbody/tr[3]/td/select");
	By status= By.xpath("//form[@name='search']/table[2]/tbody/tr[4]/td/select");
	By type= By.xpath("//form[@name='search']/table[2]/tbody/tr[5]/td/select");
	By search= By.xpath("//input[@name='DoSearch']");
	By taskname= By.xpath("//tr[@class='Row']/td[1]/a");

	
	public void set_assto() {
		WebElement we_assto=dr.findElement(assto);
		Select sel1=new Select((WebElement) we_assto);
		sel1.selectByVisibleText("Alex Knievel");
	}
	public void set_proj() {
		WebElement we_pj=dr.findElement(proj);
		Select sel1=new Select((WebElement) we_pj);
		sel1.selectByVisibleText("CodeCharge");
	}
	public void set_prio() {
		WebElement we_prio=dr.findElement(prio);
		Select sel1=new Select((WebElement) we_prio);
		sel1.selectByVisibleText("High");
	}
	public void set_status( ) {
		WebElement we_status=dr.findElement(status);
		Select sel1=new Select((WebElement) we_status);
		sel1.selectByVisibleText("Closed");
	}
	public void set_type() {
		WebElement we_type=dr.findElement(type);
		Select sel1=new Select((WebElement) we_type);
		sel1.selectByVisibleText("Bug");
	}
	public void clk_search() {
		dr.findElement(search).click();
	}
	public String get_taskname() {
		return dr.findElement(taskname).getText();
		
	}
	
	public void do_search() {
		this.set_assto();
		this.set_proj();
		this.set_prio();
		this.set_status();
		this.set_type();
		this.clk_search();
	}
	
}
