package codecharge_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class homepage_taskmanagement {
	WebDriver dr;

	public homepage_taskmanagement(WebDriver dr)
	{
		System.out.println("in homepage_taskmanagement");
		this.dr=dr;
	}
	
	By adm= By.xpath("//a[@href='Administration.php']");
	
	public void clk_adm() {
		dr.findElement(adm).click();
	}

}
