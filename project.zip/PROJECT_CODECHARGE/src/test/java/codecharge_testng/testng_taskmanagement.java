package codecharge_testng;



import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import BASE_CLASSES.Utilities;
import codecharge_pages.AddEdit_task_taskmanagement;
import codecharge_pages.homepage_taskmanagement;
import codecharge_pages.loginpage_taskmanagement;
import codecharge_pages.search_taskmanagement;

public class testng_taskmanagement extends Utilities{
	String url="http://examples.codecharge.com/TaskManager/Default.php";
	homepage_taskmanagement homepage;
	AddEdit_task_taskmanagement addedit;
	loginpage_taskmanagement login;
	search_taskmanagement search;
	Utilities util;
	@BeforeMethod
	public void lb() {
		dr=util.launch_browser("CHROME", url);
		
	}
  @Test
  public void f() throws InterruptedException {
	  homepage=new homepage_taskmanagement(dr);
	  homepage.clk_adm();
	  addedit=new AddEdit_task_taskmanagement(dr);
	  login =new loginpage_taskmanagement(dr);
	  login.do_login("admin", "admin");
	  addedit.do_addtask("india", "india is my country", "12/12/19", "12/12/20");
	  search=new search_taskmanagement(dr);
	  search.do_search();
	  String taskname=search.get_taskname();
	  Assert.assertEquals(taskname, "india");
	  
//	  SoftAssert sa= new SoftAssert();
//	  sa.assertEquals(taskname, "india");
//	  sa.assertAll();
	  
	  
  }
}
